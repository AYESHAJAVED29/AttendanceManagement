
package Entities;
public class Attendance {
    private String studentId;
   private String course;
   private String section;
   private String Date;
   private String time;

    public Attendance() {
    }

    public Attendance(String studentId, String course, String section, String Date, String time) {
        this.studentId = studentId;
        this.course = course;
        this.section = section;
        this.Date = Date;
        this.time = time;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    
}
