package Entities;

public class Enrollment {

    private Student std;
    private Course course;
    private String teacher;
    private String status;

    public Enrollment() {

    }

    public Enrollment(Student std, Course course, String teacher, String status) {
        this.std = std;
        this.course = course;
        this.teacher = teacher;
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    
    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public Student getStd() {
        return std;
    }

    public void setStd(Student std) {
        this.std = std;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

}
