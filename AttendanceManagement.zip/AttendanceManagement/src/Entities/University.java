package Entities;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;

public class University {

    private static final String ADMIN_EMAIL = "admin@university.com";
    private static final String ADMIN_PASSWORD = "admin123";

    private static ArrayList<User> users = new ArrayList<>();
    public static ArrayList<Course> courses = new ArrayList<>();
    public static ArrayList<WorkLoad> workLoads = new ArrayList<>();
    public static ArrayList<Enrollment> enrollments = new ArrayList<>();
    public static List<Attendance> presentStudent = new ArrayList<>();

    public static void dummyUsers() {
        users.add(new Teacher("Ayesha", "Pass123", "ayesha@gmail.com", "03111222333", "teacher"));
        users.add(new Teacher("Asad", "123", "asad@gmail.com", "03123456789", "teacher"));
        users.add(new Teacher("Jane Smith", "teachSecure456", "jane.smith@gmail.com", "03099887766", "teacher"));
        users.add(new Teacher("Emily Davis", "teachSafe789", "emily.davis@gmail.com", "03123456780", "teacher"));
        users.add(new Student("Ahmad", "999", "ahmad@gmail.com", "03457178589", "student"));
        users.add(new Student("Ali", "145", "ali@gmail.com", "03456789012", "student"));
        users.add(new Student("Hadi", "990", "hadi@gmail.com", "03987654321", "student"));
        users.add(new Student("Hamza", "445", "hamza@gmail.com", "03234567890", "student"));
    }

    public static ArrayList<WorkLoad> getWorkLoads() {
        return workLoads;
    }

    public static void setWorkLoads(ArrayList<WorkLoad> workLoads) {
        University.workLoads = workLoads;
    }

    public static void addUser(String name, String password, String email, String phoneNumber, String role) {
    if (name == null || password == null || email == null || phoneNumber == null || role == null
            || name.isEmpty() || password.isEmpty() || email.isEmpty() || phoneNumber.isEmpty() || role.isEmpty()) {
        dialogeMsg("All fields are required.");
        return;
    }

    if (role.equalsIgnoreCase("student")) {
        users.add(new Student(name, password, email, phoneNumber, "student"));
    } else if (role.equalsIgnoreCase("teacher")) {
        users.add(new Teacher(name, password, email, phoneNumber, "teacher"));
    } else {
        users.add(new User(name, password, email, phoneNumber, role.toLowerCase())); 
    }
    
    dialogeMsg(role + " successfully registered.");
}


    public static String loginUser(String email, String password, String role) {
        if (role.equalsIgnoreCase("admin")) {
            if (email.equalsIgnoreCase(ADMIN_EMAIL) && password.equals(ADMIN_PASSWORD)) {
                return "admin";
            } else {
                dialogeMsg("Incorrect admin email or password.");
                return null;
            }
        }
        for (User user : users) {
            if (user.getEmail().equalsIgnoreCase(email) && user.getPassword().equals(password) && user.getRole().equalsIgnoreCase(role)) {
                return role;
            }
        }
        dialogeMsg("Incorrect email or password for " + role + ".");
        return null;
    }
    
    public static void addCourseWithSections(Course course) {
        if (course == null || course.getName() == null || course.getC_code() == null
                || course.getName().isEmpty() || course.getC_code().isEmpty()) {
            dialogeMsg("Course name and code cannot be empty.");
            return;
        }
        courses.add(course);
        dialogeMsg("Course with sections successfully created!");
    }
    public static ArrayList<Course> getCourses() {
        return courses;
    }
    
    public static void dialogeMsg(String msg) {
        JOptionPane.showMessageDialog(null, msg);
    }
    
    public static String getUserNameByEmailAndRole(String email, String role) {
        for (User user : users) {
            if (user.getEmail().equalsIgnoreCase(email) && user.getRole().equalsIgnoreCase(role)) {
                return user.getName();
            }
        }
        return null;
    }

    public static void processAssignmentAndUpdateTable(String selectedTeacher, String selectedCourse, String selectedSection, DefaultTableModel model) {
        if (selectedTeacher == null || selectedCourse == null || selectedSection == null) {
            dialogeMsg("Please select a teacher, course, and section.");
            return;
        }
        Course selectedCourseObj = getCourseWithSections(selectedCourse, selectedSection);
        if (selectedCourseObj == null) {
            dialogeMsg("Course '" + selectedCourse + "' not found.");
            return;
        }
        Teacher assignedTeacher = getTeacherByName(selectedTeacher);
        if (assignedTeacher == null) {
            dialogeMsg("Teacher '" + selectedTeacher + "' not found.");
            return;
        }
        boolean courseAlreadyAssigned = false;
        for (WorkLoad workload : workLoads) {
            for (Section s : workload.getCourse().getSections()) {
                if (workload.getCourse().getName().equalsIgnoreCase(selectedCourse) && s.getName().equalsIgnoreCase(selectedSection)) {
                    if (workload.getTeacher().getName().equalsIgnoreCase(selectedTeacher)) {
                        courseAlreadyAssigned = true;
                        dialogeMsg("Course already assign ");
                        break;
                    } else {
                        courseAlreadyAssigned = true;
                        dialogeMsg("Course already assign ");
                        break;
                    }
                }
            }
        }
        if (!courseAlreadyAssigned) {
            WorkLoad newWorkLoad = new WorkLoad(assignedTeacher, selectedCourseObj);
            workLoads.add(newWorkLoad);
            model.setRowCount(0);
            for (WorkLoad workload : workLoads) {
                Course course = workload.getCourse();
                for (Section section : course.getSections()) {
                    Object[] row = new Object[5];
                    row[0] = workload.getTeacher().getName();
                    row[1] = course.getName();
                    row[2] = section.getName();
                    row[3] = section.getClass_days();
                    row[4] = section.getClass_time_slot();
                    model.addRow(row);
                }
            }
            dialogeMsg("Section '" + selectedSection + "' assigned to teacher '" + selectedTeacher + "' for course '" + selectedCourse + "with section " + selectedSection);
        }
    }

    public static ArrayList<User> getAllTeachers() {
        ArrayList<User> teachers = new ArrayList<>();
        for (User user : users) {
            if (user.getRole().equalsIgnoreCase("teacher")) {
                teachers.add(user);
            }
        }
        return teachers;
    }

    public static ArrayList<User> getAllStudents() {
        ArrayList<User> students = new ArrayList<>();
        for (User user : users) {
            if (user.getRole().equalsIgnoreCase("student")) {
                students.add(user);
            }
        }
        return students;
    }

    public static ArrayList<Section> getSectionsByCourseName(String courseName) {
        Course course = getCourseByName(courseName);
        return course != null ? course.getSections() : new ArrayList<>();
    }

    public static String getAssignedTeacherForSection(String courseName, String sectionName) {
        for (WorkLoad workload : workLoads) {
            if (workload.getCourse().getName().equalsIgnoreCase(courseName)) {
                for (Section section : workload.getCourse().getSections()) {
                    if (section.getName().equalsIgnoreCase(sectionName)) {
                        return workload.getTeacher().getName();
                    }
                }
            }
        }
        return null;
    }

    public static boolean enrollStudentInSection(String studentName, String courseName, String sectionName, String teacher) {

        Course course = getCourseWithSections(courseName, sectionName);
        Section section = getSectionByName(courseName, sectionName);
        if (course == null) {
            dialogeMsg("Course '" + courseName + "' not found.");
            return false;
        }
        if (section == null) {
            dialogeMsg("Section '" + sectionName + "' not found.");
            return false;
        }
        Student enrolledStudent = getStudentByName(studentName);
        if (enrolledStudent == null) {
            dialogeMsg("Student '" + studentName + "' not found.");
            return false;
        }
        if (isStudentEnrolledAlready(studentName.trim(), courseName.trim())) {
            dialogeMsg("Student '" + studentName + "' is already enrolled in course '" + courseName + "'.");
            return false;
        }
        Enrollment enrollment = new Enrollment(enrolledStudent, course, teacher,"Pending");
        enrollments.add(enrollment);
        dialogeMsg("Student '" + studentName + "' successfully enrolled in course '" + courseName + "', section '" + sectionName + "'.");
        return true;
    }

    public static Course getCourseByName(String courseName) {
        for (Course course : courses) {
            if (course.getName().equalsIgnoreCase(courseName)) {
                return course;
            }
        }
        return null;
    }

    public static Course getCourseWithSections(String courseName, String sectionName) {
        for (Course c : courses) {
            if (c.getName().equalsIgnoreCase(courseName.trim())) {
                ArrayList<Section> matchedSections = new ArrayList<>();
                for (Section s : c.getSections()) {
                    if (s.getName().equalsIgnoreCase(sectionName.trim())) {
                        matchedSections.add(s);
                        return new Course(c.getName(), c.getC_code(), matchedSections);
                    }
                }
            }
        }
        return null;
    }

    public static Section getSectionByName(String courseName, String sectionName) {
        Course course = getCourseByName(courseName);
        if (course != null) {
            for (Section section : course.getSections()) {
                if (section.getName().equalsIgnoreCase(sectionName)) {
                    return section;
                }
            }
        }
        return null;
    }

    public static Student getStudentByName(String studentName) {
        for (User user : users) {
            if (user instanceof Student && user.getName().equalsIgnoreCase(studentName)) {
                return (Student) user;
            }
        }
        return null;
    }

    public static boolean isStudentEnrolledAlready(String student, String course) {
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getStd().getName().equalsIgnoreCase(student) && enrollment.getCourse().getName().equalsIgnoreCase(course)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isCourseAssignedToTeacher(String teacherName, String courseName) {
        for (WorkLoad workload : workLoads) {
            if (workload.getTeacher().getName().equalsIgnoreCase(teacherName)
                    && workload.getCourse().getName().equalsIgnoreCase(courseName)) {
                return true;
            }
        }
        return false;
    }

    public static Teacher getTeacherByName(String teacherName) {
        for (User user : users) {
            if (user instanceof Teacher && user.getName().equalsIgnoreCase(teacherName) && user.getRole().equalsIgnoreCase("Teacher")) {
                return (Teacher) user;
            }
        }
        return null;
    }
}
