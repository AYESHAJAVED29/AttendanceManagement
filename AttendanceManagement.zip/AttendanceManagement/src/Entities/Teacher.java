
package Entities;
    public class Teacher extends User {
   public Teacher(String name, String password, String email, String phoneNumber, String role) {
        super(name, password, email, phoneNumber, role);
    }
}

    

