
package Entities;

public class Student extends User{
   public Student(String name, String password, String email, String phoneNumber, String role) {
        super(name, password, email, phoneNumber, role);
    }
}
