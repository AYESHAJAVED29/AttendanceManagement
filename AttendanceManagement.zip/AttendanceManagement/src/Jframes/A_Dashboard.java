/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Jframes;

import Entities.Attendance;
import Entities.Course;
import Entities.Section;
import Entities.Student;
import Entities.University;
import static Entities.University.workLoads;
import Entities.User;
import Entities.WorkLoad;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ayesh
 */
public class A_Dashboard extends javax.swing.JFrame {

    /**
     * Creates new form Dashboard
     */
     private String selectedCourse;
     private String selectedSection;
     private String selectedTeacher;
     private String selectedCourses;
   // Constructor for the dashboard
     public A_Dashboard() {
        initComponents();
        this.setBounds(300, 100, 785, 555);
        University.dummyUsers();
        updateTeacherTable();
        updateStudentTable();
        updateTeacherComboBox();
        updateCourseComboBox();
        String selectedCourse = (String) courseComboBox.getSelectedItem();
        if (selectedCourse != null) {
            updateSectionComboBox(selectedCourse);
        }

    }

    private void addComboBoxListeners() {
     
        courseComboBox.addActionListener(e -> {
            String selectedCourse = (String) courseComboBox.getSelectedItem();
            updateSectionComboBox(selectedCourse);
            updateTable();
        });
        sectionComboBox.addActionListener(e -> updateTable());
    }

    private void updateCourseComboBox() {
        courseComboBox.removeAllItems(); 
        for (Course course : University.getCourses()) {
            courseComboBox.addItem(course.getName());
        }
    }

    private void updateSectionComboBox(String courseName) {
        sectionComboBox.removeAllItems(); 
        for (Course course : University.getCourses()) {
            if (course.getName().equalsIgnoreCase(courseName)) {
                for (Section section : course.getSections()) {
                    sectionComboBox.addItem(section.getName()); 
                }
                break;
            }
        }
    }
    
    
    private void addSection() {
        DefaultTableModel model = (DefaultTableModel) sectionTable.getModel();
        model.addRow(new Object[]{"", "", ""});
    }

    private void removeSelectedSection() {
        DefaultTableModel model = (DefaultTableModel) sectionTable.getModel();
        int selectedRow = sectionTable.getSelectedRow();
        if (selectedRow != -1) {
            model.removeRow(selectedRow);
            University.dialogeMsg("Selected section removed.");
        } else {
            University.dialogeMsg("No section selected to remove.");
        }
    }

    private void createCourse() {
        String courseName = courseNameField.getText().trim();
        String courseCode = courseCodeField.getText().trim();
        ArrayList<Section> sections = new ArrayList<>();
        DefaultTableModel model = (DefaultTableModel) sectionTable.getModel();
        for (int i = 0; i < model.getRowCount(); i++) {
            String sectionName = (String) model.getValueAt(i, 0);
            String day = (String) model.getValueAt(i, 1);
            String time = (String) model.getValueAt(i, 2);
            if (!sectionName.isEmpty()) {
                sections.add(new Section(sectionName, day, time));
            }
        }
        if (courseName.isEmpty() || courseCode.isEmpty()) {
            University.dialogeMsg("Course name and code cannot be empty.");
            return;
        }
        if (sections.isEmpty()) {
            University.dialogeMsg("At least one section is required.");
            return;
        }
        Course course = new Course(courseName, courseCode, sections);
        University.addCourseWithSections(course);
        updateCourseComboBox(); 
        courseComboBox.setSelectedItem(courseName);
        updateSectionComboBox(courseName);
    }

    public void updateTeacherTable() {
        ArrayList<User> teachers = University.getAllTeachers();
        if (teachers != null && !teachers.isEmpty()) {
            DefaultTableModel model = (DefaultTableModel) teacherTable.getModel();
            model.setRowCount(0);
            for (User teacher : teachers) {
                Object[] rowData = new Object[3];
                rowData[0] = teacher.getName();
                rowData[1] = teacher.getEmail();
                rowData[2] = teacher.getPhoneNumber();
                model.addRow(rowData);
            }
        }
    }
    
    public void updateStudentTable() {
        ArrayList<User> students = University.getAllStudents();
        if (students != null && !students.isEmpty()) {
            DefaultTableModel model = (DefaultTableModel) studentTable.getModel();
            model.setRowCount(0);
            for (User student : students) {
                Object[] rowData = new Object[3];
                rowData[0] = student.getName();
                rowData[1] = student.getEmail();
                rowData[2] = student.getPhoneNumber();
                model.addRow(rowData);
            }
        }
    }

    public void updateTable() {
        DefaultTableModel model = (DefaultTableModel) adminTable.getModel();
        model.setRowCount(0);
        String selectedTeacher = (String) teacherComboBox.getSelectedItem();
        String selectedCourse = (String) courseComboBox.getSelectedItem();
        String selectedSection = (String) sectionComboBox.getSelectedItem();

        if (selectedTeacher == null || selectedCourse == null || selectedSection == null) {
            return;
        }
        ArrayList<User> teachers = University.getAllTeachers();
        for (User teacher : teachers) {
            if (selectedTeacher.equals(teacher.getName())) {
                String classDays = "";
                String classTimeSlot = "";
                for (Course course : University.getCourses()) {
                    if (course.getName().equalsIgnoreCase(selectedCourse)) {
                        for (Section section : course.getSections()) {
                            if (section.getName().equalsIgnoreCase(selectedSection)) {
                                classDays = section.getClass_days();
                                classTimeSlot = section.getClass_time_slot();
                                break;
                            }
                        }
                    }
                }
                Object[] row = new Object[5];
                row[0] = teacher.getName();
                row[1] = selectedCourse;
                row[2] = selectedSection;
                row[3] = classDays;
                row[4] = classTimeSlot;
                model.addRow(row);
            }
        }
    }

    private void updateTeacherComboBox() {
        teacherComboBox.removeAllItems();
        teacherCombo.removeAllItems();
        ArrayList<User> teachers = University.getAllTeachers();
        for (User teacher : teachers) {
            teacherComboBox.addItem(teacher.getName()); 
            teacherCombo.addItem(teacher.getName());
        }
    }

  private void assignCourseToTeacher() {
    String selectedTeacher = (String) teacherComboBox.getSelectedItem();
    String selectedCourse = (String) courseComboBox.getSelectedItem();
    String selectedSection = (String) sectionComboBox.getSelectedItem();

    if (selectedTeacher == null || selectedCourse == null || selectedSection == null) {
        University.dialogeMsg("Please select a teacher, course, and section.");
        return;
    }
    University.processAssignmentAndUpdateTable(selectedTeacher, selectedCourse, selectedSection, (DefaultTableModel) adminTable.getModel());
  
}
  
 private void populateCourseComboBoxes(String selectedTeacher) {
    courseCombo.removeAllItems(); 
    for (WorkLoad workLoad : workLoads) {
        if (workLoad.getTeacher().getName().equalsIgnoreCase(selectedTeacher)) {
            Course course = workLoad.getCourse();
            String courseName = course.getName();
            boolean alreadyAdded = false;
            for (int i = 0; i < courseCombo.getItemCount(); i++) {
                if (courseCombo.getItemAt(i).equalsIgnoreCase(courseName)) {
                    alreadyAdded = true;
                    break;
                }
            }
            if (!alreadyAdded) {
                courseCombo.addItem(courseName);
            }
        }
    }
}

  private void populateSectionComboBox(String chosenCourse) {
        sectionCombo.removeAllItems();
        ArrayList<Section> sections = University.getSectionsByCourseName(chosenCourse);  
        for (Section section : sections) {
            sectionCombo.addItem(section.getName()); 
        }
    }
  
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox7 = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        sectionTable = new javax.swing.JTable();
        removeSelectedRowButton = new javax.swing.JButton();
        createCourseButton = new javax.swing.JButton();
        addRowButton = new javax.swing.JButton();
        courseNameField = new javax.swing.JTextField();
        courseCodeField = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        studentTable = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        teacherTable = new javax.swing.JTable();
        jPanel10 = new javax.swing.JPanel();
        teacherComboBox = new javax.swing.JComboBox<>();
        courseComboBox = new javax.swing.JComboBox<>();
        sectionComboBox = new javax.swing.JComboBox<>();
        assign = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        adminTable = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        courseCombo = new javax.swing.JComboBox<>();
        sectionCombo = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableModel1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        dateTextField = new javax.swing.JTextField();
        timeTextField = new javax.swing.JTextField();
        teacherCombo = new javax.swing.JComboBox<>();

        jComboBox7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "***Student Name***", "Item 2", "Item 3", "Item 4" }));
        jComboBox7.setBorder(new javax.swing.border.MatteBorder(null));
        jComboBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox7ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/home.png"))); // NOI18N
        jLabel1.setText("   Home");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/open-book.png"))); // NOI18N
        jLabel2.setText(" Course portal");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/log-out.png"))); // NOI18N
        jLabel6.setText("   Log out");
        jLabel6.setIconTextGap(5);
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/reading.png"))); // NOI18N
        jLabel7.setText(" Student Portal");
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/teacher.png"))); // NOI18N
        jLabel8.setText(" Teacher Portal");
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/search.png"))); // NOI18N
        jLabel9.setText("  A-Portal");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(22, 22, 22)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel6)
                                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(20, 20, 20)
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(19, 19, 19)))
                        .addGap(0, 8, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addComponent(jLabel1)
                .addGap(39, 39, 39)
                .addComponent(jLabel2)
                .addGap(47, 47, 47)
                .addComponent(jLabel7)
                .addGap(43, 43, 43)
                .addComponent(jLabel8)
                .addGap(45, 45, 45)
                .addComponent(jLabel9)
                .addGap(46, 46, 46)
                .addComponent(jLabel6)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel1.setBackground(new java.awt.Color(102, 153, 204));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("tab1", jPanel1);

        jPanel3.setBackground(new java.awt.Color(204, 102, 102));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Course code");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("Section code");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setText("Course name");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("Section name");

        sectionTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Section name", "day", "time"
            }
        ));
        jScrollPane6.setViewportView(sectionTable);

        removeSelectedRowButton.setBackground(new java.awt.Color(51, 51, 51));
        removeSelectedRowButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        removeSelectedRowButton.setForeground(new java.awt.Color(100, 149, 237));
        removeSelectedRowButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/plus.png"))); // NOI18N
        removeSelectedRowButton.setText("  delete");
        removeSelectedRowButton.setBorder(new javax.swing.border.MatteBorder(null));
        removeSelectedRowButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeSelectedRowButtonActionPerformed(evt);
            }
        });

        createCourseButton.setBackground(new java.awt.Color(51, 51, 51));
        createCourseButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        createCourseButton.setForeground(new java.awt.Color(100, 149, 237));
        createCourseButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/plus.png"))); // NOI18N
        createCourseButton.setText("        Create Course");
        createCourseButton.setBorder(new javax.swing.border.MatteBorder(null));
        createCourseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createCourseButtonActionPerformed(evt);
            }
        });

        addRowButton.setBackground(new java.awt.Color(51, 51, 51));
        addRowButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        addRowButton.setForeground(new java.awt.Color(100, 149, 237));
        addRowButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/plus.png"))); // NOI18N
        addRowButton.setText("   add");
        addRowButton.setBorder(new javax.swing.border.MatteBorder(null));
        addRowButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addRowButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(42, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(addRowButton, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(courseNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(98, 98, 98)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(courseCodeField, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel10))
                    .addComponent(removeSelectedRowButton, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(createCourseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(141, 141, 141))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(courseCodeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel10))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(addRowButton)
                        .addGap(10, 10, 10))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(removeSelectedRowButton)
                        .addGap(18, 18, 18)))
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(createCourseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab2", jPanel3);

        jPanel4.setBackground(new java.awt.Color(204, 153, 102));

        jPanel7.setBackground(new java.awt.Color(204, 153, 102));

        studentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Name", "Email", "Ph-no"
            }
        ));
        jScrollPane2.setViewportView(studentTable);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 538, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 439, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("List of student", jPanel7);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2))
        );

        jTabbedPane1.addTab("tab3", jPanel4);

        jPanel5.setBackground(new java.awt.Color(45, 89, 134));

        jPanel9.setBackground(new java.awt.Color(45, 89, 134));

        teacherTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Teacher Name", "E_mail", "Ph_no"
            }
        ));
        jScrollPane5.setViewportView(teacherTable);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("List of teachers", jPanel9);

        jPanel10.setBackground(new java.awt.Color(204, 204, 102));

        teacherComboBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        teacherComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "***Select Teacher***", "Item 2", "Item 3", "Item 4" }));
        teacherComboBox.setBorder(new javax.swing.border.MatteBorder(null));

        courseComboBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        courseComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "***Select  Course***", "Item 2", "Item 3", "Item 4" }));
        courseComboBox.setBorder(new javax.swing.border.MatteBorder(null));
        courseComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                courseComboBoxActionPerformed(evt);
            }
        });

        sectionComboBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        sectionComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "***Select Section***", "Item 2", "Item 3", "Item 4" }));
        sectionComboBox.setBorder(new javax.swing.border.MatteBorder(null));

        assign.setBackground(new java.awt.Color(102, 153, 204));
        assign.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        assign.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/assignment.png"))); // NOI18N
        assign.setText("  Assigned");
        assign.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        assign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                assignActionPerformed(evt);
            }
        });

        adminTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Teacher Name", "Section", "Course", "Date", "Time"
            }
        ));
        jScrollPane4.setViewportView(adminTable);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(assign, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(teacherComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(courseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(sectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 40, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(teacherComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(courseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 379, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(assign, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        jTabbedPane3.addTab("WorkloadPortal", jPanel10);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane3)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane3, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        jTabbedPane1.addTab("tab4", jPanel5);

        jPanel6.setBackground(new java.awt.Color(150, 185, 220));

        courseCombo.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        courseCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "***Select Course***", "PF", "OOP", "OOK" }));
        courseCombo.setBorder(new javax.swing.border.MatteBorder(null));
        courseCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                courseComboActionPerformed(evt);
            }
        });

        sectionCombo.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        sectionCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "***Select Section***", "W1", "W2", "W3" }));
        sectionCombo.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Date");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Time");

        tableModel1.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        tableModel1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Name", "Status"
            }
        ));
        jScrollPane1.setViewportView(tableModel1);

        jButton1.setBackground(new java.awt.Color(51, 51, 51));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/save-instagram.png"))); // NOI18N
        jButton1.setText("  Show");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        teacherCombo.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        teacherCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "***Select teacher***", "Item 2", "Item 3", "Item 4" }));
        teacherCombo.setBorder(new javax.swing.border.MatteBorder(null));
        teacherCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherComboActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(timeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(62, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(385, 413, Short.MAX_VALUE))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jScrollPane1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addComponent(teacherCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(courseCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(sectionCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(28, 28, 28))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(dateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(teacherCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(courseCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sectionCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 359, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );

        jTabbedPane1.addTab("tab5", jPanel6);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, -40, 600, 570));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
         jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        // TODO add your handling code here:
         jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        // TODO add your handling code here:
         jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
         jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jComboBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox7ActionPerformed

    private void removeSelectedRowButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeSelectedRowButtonActionPerformed
        // TODO add your handling code here:
         removeSelectedSection();
    }//GEN-LAST:event_removeSelectedRowButtonActionPerformed

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        this.setVisible(false);
        this.dispose();
        Dashboard sgin = new Dashboard();
        sgin.setVisible(true);
    }//GEN-LAST:event_jLabel6MouseClicked

    private void createCourseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createCourseButtonActionPerformed
        // TODO add your handling code here:
         createCourse();
         updateCourseComboBox();
    }//GEN-LAST:event_createCourseButtonActionPerformed

    private void addRowButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addRowButtonActionPerformed
        // TODO add your handling code here:
       addSection();
    }//GEN-LAST:event_addRowButtonActionPerformed

    private void assignActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assignActionPerformed
        // TODO add your handling code here:
       assignCourseToTeacher();
        
    }//GEN-LAST:event_assignActionPerformed

    private void courseComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_courseComboBoxActionPerformed
        // TODO add your handling code here:
        String selectedCourse = (String) courseComboBox.getSelectedItem();
    updateSectionComboBox(selectedCourse);
    }//GEN-LAST:event_courseComboBoxActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    String selectedCourse = (String) courseCombo.getSelectedItem();
    String selectedSection = (String) sectionCombo.getSelectedItem();
    if (selectedCourse != null && selectedSection != null 
        && !"***Select Course***".equals(selectedCourse) 
        && !"***Select Section***".equals(selectedSection)) {
        DefaultTableModel model = (DefaultTableModel) tableModel1.getModel();
        model.setRowCount(0); 
        String date = null;
        String time = null;
        for (Attendance attendance : University.presentStudent) {
            if (attendance.getCourse().equalsIgnoreCase(selectedCourse)
                && attendance.getSection().equalsIgnoreCase(selectedSection)) {
                Object[] row = {
                    attendance.getStudentId(),  // Student name or ID
                    "P"                         // Default status "P"
                };
                model.addRow(row);  
                if (date == null && time == null) {
                    date = attendance.getDate();
                    time = attendance.getTime();
                }
            }
        }
        if (date != null && time != null) {
            dateTextField.setText(date);
            timeTextField.setText(time);
        } else {
            dateTextField.setText("");
            timeTextField.setText("");
            University.dialogeMsg("No attendance records found for the selected course and section.");
        }
    } else {
            University.dialogeMsg("Please select a course and section.");
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void courseComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_courseComboActionPerformed
        // TODO add your handling code here:
     String chosenCourse = (String) courseCombo.getSelectedItem();  
            if (chosenCourse != null) {
                populateSectionComboBox(chosenCourse);  
            }
    }//GEN-LAST:event_courseComboActionPerformed

    private void teacherComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherComboActionPerformed
        // TODO add your handling code here:
         String selectedTeacher = (String) teacherCombo.getSelectedItem(); 
        if (selectedTeacher != null) {
            populateCourseComboBoxes(selectedTeacher);  
        }
    }//GEN-LAST:event_teacherComboActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(A_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(A_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(A_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(A_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new A_Dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addRowButton;
    private javax.swing.JTable adminTable;
    private javax.swing.JButton assign;
    private javax.swing.JTextField courseCodeField;
    private javax.swing.JComboBox<String> courseCombo;
    private javax.swing.JComboBox<String> courseComboBox;
    private javax.swing.JTextField courseNameField;
    private javax.swing.JButton createCourseButton;
    private javax.swing.JTextField dateTextField;
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JButton removeSelectedRowButton;
    private javax.swing.JComboBox<String> sectionCombo;
    private javax.swing.JComboBox<String> sectionComboBox;
    private javax.swing.JTable sectionTable;
    private javax.swing.JTable studentTable;
    private javax.swing.JTable tableModel1;
    private javax.swing.JComboBox<String> teacherCombo;
    private javax.swing.JComboBox<String> teacherComboBox;
    public javax.swing.JTable teacherTable;
    private javax.swing.JTextField timeTextField;
    // End of variables declaration//GEN-END:variables
}
