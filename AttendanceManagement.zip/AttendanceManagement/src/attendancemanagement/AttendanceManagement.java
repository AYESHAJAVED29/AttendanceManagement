
package attendancemanagement;

import Jframes.Dashboard;
import Jframes.LoginIn;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AttendanceManagement {
    public static void main(String[] args) {
        // TODO code application logic here
        
    }
    
}
